WITH clean_1 AS
(SELECT *,
	CASE
		WHEN land_use_name IN ('Urban','Rural') THEN land_use_name
		ELSE 'OTHERS' END land_use_name_new
FROM crash),

-- Time Zone Adjustment
clean_2 AS
(SELECT *,
 CASE
	WHEN state_name IN ('Connecticut','Delaware','District of Columbia','Florida','Georgia','Indiana','Kentucky','Maine','Maryland',
						'Massachusetts','Michigan','New Hampshire','New Jersey','New York','North Carolina','Ohio','Pennsylvania',
						'Rhode Island','South Carolina','Tennessee','Vermont','Virginia','West Virginia') 
 						THEN timestamp_of_crash AT TIME ZONE 'EST'
 	WHEN state_name IN ('Alabama','Arkansas','Illinois','Iowa','Kansas','Louisiana','Minnesota','Mississippi','Missouri','Nebraska',
						'North Dakota','South Dakota','Oklahoma','Texas','Wisconsin')	THEN timestamp_of_crash AT TIME ZONE 'CST'
 	WHEN state_name IN ('Arizona','Colorado','Idaho','Montana','New Mexico','Oregon','Utah','Wyoming') THEN timestamp_of_crash AT TIME ZONE 'MST'
 	WHEN state_name IN ('California','Nevada','Washington') THEN timestamp_of_crash AT TIME ZONE 'PST'
	WHEN state_name IN ('Alaska') THEN timestamp_of_crash AT TIME ZONE 'AKST'
 -- Hawaiian Time
	ELSE timestamp_of_crash AT TIME ZONE 'HST' END adjusted_timestamp
FROM clean_1),

--- Filtering tahun 2021 saja
clean_3 AS
(SELECT * FROM clean_2 
WHERE EXTRACT(YEAR FROM adjusted_timestamp) = 2021)

--Parent Query: Presentase kecelakaan karena mabuk
SELECT COUNT(consecutive_number) AS jml_kecelakaan,
	COUNT(CASE WHEN number_of_drunk_drivers > 0 THEN 1 END) AS jml_kecelakaan_krn_mabuk,
	COUNT(CASE WHEN number_of_drunk_drivers > 0 THEN 1 END) * 100.0 / COUNT(consecutive_number) AS persentase_kecelakaan_krn_mabuk
FROM clean_3

