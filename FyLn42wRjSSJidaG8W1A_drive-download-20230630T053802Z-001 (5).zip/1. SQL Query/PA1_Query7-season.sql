WITH clean_1 AS
(SELECT *,
	CASE
		WHEN land_use_name IN ('Urban','Rural') THEN land_use_name
		ELSE 'OTHERS' END land_use_name_new
FROM crash),

-- Time Zone Adjustment
clean_2 AS
(SELECT *,
 CASE
	WHEN state_name IN ('Connecticut','Delaware','District of Columbia','Florida','Georgia','Indiana','Kentucky','Maine','Maryland',
						'Massachusetts','Michigan','New Hampshire','New Jersey','New York','North Carolina','Ohio','Pennsylvania',
						'Rhode Island','South Carolina','Tennessee','Vermont','Virginia','West Virginia') 
 						THEN timestamp_of_crash AT TIME ZONE 'EST'
 	WHEN state_name IN ('Alabama','Arkansas','Illinois','Iowa','Kansas','Louisiana','Minnesota','Mississippi','Missouri','Nebraska',
						'North Dakota','South Dakota','Oklahoma','Texas','Wisconsin')	THEN timestamp_of_crash AT TIME ZONE 'CST'
 	WHEN state_name IN ('Arizona','Colorado','Idaho','Montana','New Mexico','Oregon','Utah','Wyoming') THEN timestamp_of_crash AT TIME ZONE 'MST'
 	WHEN state_name IN ('California','Nevada','Washington') THEN timestamp_of_crash AT TIME ZONE 'PST'
	WHEN state_name IN ('Alaska') THEN timestamp_of_crash AT TIME ZONE 'AKST'
 -- Hawaiian Time
	ELSE timestamp_of_crash AT TIME ZONE 'HST' END adjusted_timestamp
FROM clean_1),

--- Filtering tahun 2021 saja
clean_3 AS
(SELECT * FROM clean_2 
WHERE EXTRACT(YEAR FROM adjusted_timestamp) = 2021),

-- Cleaning atribut type_of_intersection_name
clean_4 AS
(SELECT *,
	CASE
		WHEN type_of_intersection_name IN ('Y-Intersection','Five Point, or More','Four-Way Intersection',
										  'L-Intersection','Traffic Circle','Roundabout','T-Intersection','Not an Intersection') 
 		THEN type_of_intersection_name
		ELSE 'OTHERS' END type_of_intersection_new
FROM clean_3),

-- Cleaning atribut light_condition_name
clean_5 AS
(SELECT *,
	CASE
		WHEN light_condition_name='Dark - Unknown Lighting' THEN 'Dark'
 		WHEN light_condition_name IN ('Dusk','Dark - Lighted','Dawn') THEN 'Dim'
 		WHEN light_condition_name='Daylight' THEN 'Daylight'
 		WHEN light_condition_name='Dark - Not Lighted' THEN 'Dark'
		ELSE 'OTHERS' END light_condition_new
FROM clean_4),

-- Cleaning atribut atmospheric_conditions_1_name
clean_6 AS
(SELECT *,
	CASE
		WHEN atmospheric_conditions_1_name IN ('Reported as Unknown','Other','Not Reported') THEN 'OTHERS'
 		ELSE atmospheric_conditions_1_name END atmospheric_conditions_new
FROM clean_5),

-- kategorisasi timestamp menjadi 4 seasons
clean_7 AS
(SELECT *,
	EXTRACT(MONTH FROM adjusted_timestamp) AS bulan_kejadian,
 	CASE
 		WHEN EXTRACT(MONTH FROM adjusted_timestamp) BETWEEN 10 AND 12 THEN 'Autumn-gugur'
 		WHEN EXTRACT(MONTH FROM adjusted_timestamp) BETWEEN 1 AND 3 THEN 'Winter-dingin'
		WHEN EXTRACT(MONTH FROM adjusted_timestamp) BETWEEN 4 AND 6 THEN 'Spring-semi'
 		ELSE 'Summer-panas' END AS season_musim
FROM clean_6),

-- Basis tabel untuk analisa resiko kecelakaan
table_basis AS
(SELECT season_musim, consecutive_number, number_of_fatalities
FROM clean_7)

--- Jumlah kecelakaan berdasarkan musim
SELECT season_musim,
		COUNT(consecutive_number) AS jml_kecelakaan_per_musim,
		SUM(number_of_fatalities) AS jml_korban,
		SUM(number_of_fatalities) *1.0 / COUNT(*) AS fatality_rate
FROM table_basis
GROUP BY season_musim
ORDER BY fatality_rate DESC
